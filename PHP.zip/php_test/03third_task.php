<?php
require_once 'readline.php';

$x = readline("enter a number: ");
$array = [1,2,3,4,5,6,7,8,9,10];



function func($array, $x) {
	$result = 1;
	$n = count($array) - 1;
	if ($x <= 0) {
		return 0;
	}
	if ($array[$n] % 2 == 1) {
		$result *= $array[$n];
	}
	$n++;
	echo $result;
	return func($array, $n--);
}

echo func($array, $x);