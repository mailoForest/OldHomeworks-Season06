<?php
function &bar()
{
	$a = 5;
	return $a;
}
echo bar();