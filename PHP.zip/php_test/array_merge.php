<?php

$array1 = ["a" => 5, "b" => 6, "c" => 7];
$array2 = [0 => 1, "1a" => 2, 2 =>3];
$array3 = ["a" => 1, "b" => 2, "c" => 3];
$array4 = [0 => 4, "1a" => 5, 2 => 6];

$array = array_merge($array2, $array4);

print_r($array);							//l

foreach ($array as $key => $value) {
	$array[$key]++;
}
$array = array_values($array);
print_r($array);							//@author Kaloyan


$arraySum = $array1 + $array2;

print_r($arraySum);							//a
