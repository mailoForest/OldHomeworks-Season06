<?php

$a = 222.1;

var_dump($a);
$b = (int) $a;
var_dump($b);

settype($a, "string");

var_dump($a);
