<?php

$string1 = "В квартала няма кучета, риба, пържени картофи. Това е така заради глобалтото затопляне.";
$string2 = "В квартала обаче има котки. Има ги, защото обичат жегата.";

$string1 = str_replace(",", "", $string1);
$string1 = str_replace(".", "", $string1);
$string2 = str_replace(",", "", $string2);
$string2 = str_replace(".", "", $string2);

$array1 = explode(" ", $string1);
$array2 = explode(" ", $string2);

//$array = array_diff($array1, $array2);

for ($i = 0; $i < count($array2); $i++) {	
	if ($i == array_search($array2[$i], $array1)){
		unset($array1[$i]);
	}
}
$e = implode(", ", $array1);

echo "The words are: $e.";