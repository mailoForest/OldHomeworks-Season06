<?php

$a = "str";
echo is_string($a);
echo gettype($a);

