<?php

$a = 5;
$b = 6;

echo $a, $b;
