<?php

$array = array_fill(0, 5, 0);

print_r($array);