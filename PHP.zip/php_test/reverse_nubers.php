<?php
require_once 'readline.php';

$a = readline("Enter the number you wish to reverse: ");
$b = 0;

while ($a){
	$b *= 10;
	$b += $a%10;
	$a = floor($a/10);
}
echo $b;