<?php
require_once 'readline.php';

$counter = 0;

function card($card){
	switch ($card) {
		case "T";	$card = 10;	break;
		case "J";	$card = 11;	break;
		case "Q";	$card = 12;	break;
		case "K";	$card = 13;	break;
		case "A";	$card = 14;	break;
	}
	return $card;
}

while (true) {
	echo "Enter the strenght of three cards in ascending order:", PHP_EOL;
	$card1 = readline("-first card: ");
	$card2 = readline("-second card: ");
	$card3 = readline("-third card: ");
	$counter++;
	
	if ($card1 > 9 || $card2 > 9 || $card3 > 9) {
		echo "Invalid cards given", PHP_EOL;
		continue;
	}
	if (card($card1) < card($card2) && card($card2) < card($card3) && card($card1) > 1 && card($card3) < 15) {
		echo "Number of tries: $counter";
		break;
	} else {
		echo "Invalid cards given!", PHP_EOL;
	}
}


