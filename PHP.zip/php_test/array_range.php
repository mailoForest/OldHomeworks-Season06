<?php

require_once 'readline.php';
$a = readline("enter a number: ");

$array = range(0, $a-1);

print_r($array);

