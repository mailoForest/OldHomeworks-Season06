<?php

function sum($a, $b, $absouteValue = false) {
	if ($absouteValue) {
		return abs($a) + abs($b);
	}
	
	return  $a + $b;
}

echo sum(-1, 2);