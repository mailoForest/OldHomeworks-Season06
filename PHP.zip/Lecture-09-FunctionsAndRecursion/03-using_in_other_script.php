<?php

require_once '01-basic-function.php';

sum();

$c = 123;