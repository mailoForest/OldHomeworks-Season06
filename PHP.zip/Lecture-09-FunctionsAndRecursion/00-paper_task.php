<?php

$string = 'Baba gotvi manja';
$vowels = ['a', 'e', 'i', 'o', 'u'];
/* 
$replace = ['ay', 'ey', 'iy', 'oy', 'uy'];

echo str_replace($vowels, $replace, $string); */

$result = '';

for ($i = 0; $i < strlen($string); $i++) {
	$result .= in_array($string[$i], $vowels) ? $string[$i]  .'y' : $string[$i];
}

echo $result;