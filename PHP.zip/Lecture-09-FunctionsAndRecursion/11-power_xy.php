<?php

/**
 * @param number $x
 * @param number $y
 */
function powerXY($x, $y){
	if ($y <= 0) {
		return 1;
	}
	
	return powerXY($x, $y - 1) * $x;
}

echo powerXY(2, 4);