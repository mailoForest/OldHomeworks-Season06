<?php

function sum($a, $b) {
	return $a + $b;
	echo '1234';
	
}
sum(1, 2);


$result = sum(1, 2);

echo $result;
var_dump($result);