<?php

$a = 5;

function increase(&$param) {
	$param++;
	var_dump($param);
}

increase($a);

var_dump($a);