<?php

$array = [1, 2, 3, 4, 5,];

function iterate($array, $i) {
	if ($i >= count($array)) {
		return ;
	}
	
	echo $array[$i], PHP_EOL;
	
	iterate($array, ++$i);
}

iterate($array, 0);