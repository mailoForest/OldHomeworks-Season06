<?php

function average($array) {
	$count = 0;
	$sum = 0;
	
	foreach ($array as $value) {
		$sum += $value;
		$count++;
	}
	
	return $sum / $count;
}

function smart_average() {
	$args = func_get_args();
	
	return array_sum($args) / count($args);
}

//$result = average([1, 2, 3]);
$result = smart_average(1, 2, 3, 4, 5, 6);
echo $result;