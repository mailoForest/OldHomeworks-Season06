<?php


function test($t) {
	
	echo $t;
}

test('alabala');