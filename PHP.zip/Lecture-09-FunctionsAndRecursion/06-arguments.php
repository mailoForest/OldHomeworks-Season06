<?php

$first = 1;
$second = 2;

function sum($a, $b) {
	echo $a + $b;
}

sum($first, $second);