<?php

$a = 125;

function sum() {
	//$a = 5;
	$a = $GLOBALS['a'];
	//global $a;
	$b = 6;	
	echo $a + $b;
}

//sum();

print_r($_SERVER['argv']);