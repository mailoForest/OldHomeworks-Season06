<?php

return [
	'dbHost' => 'localhost',
	'pass' => 'dadsadad',
	'url' => 'http://test.com'
	
];