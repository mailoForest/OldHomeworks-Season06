<?php

for ($i = -20; $i <= 50; $i++) {
	echo "$i ";
}