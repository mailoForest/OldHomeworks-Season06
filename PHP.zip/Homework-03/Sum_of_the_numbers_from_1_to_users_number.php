<?php

require_once 'readline.php';

$users_number = readline('Enter a number: ');
$sum = 0; 

for ($i = $sum; $i <= $users_number; $i++) {
	$sum += $i; 
}
echo("$sum");
