<?php

for ($i = -10; $i <= 10; $i++) {
	
	if (abs($i) % 2 == 1) {
		echo "$i ";
	}
}