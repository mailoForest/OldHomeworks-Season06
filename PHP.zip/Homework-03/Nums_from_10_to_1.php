<?php

for ($i = 10; $i >= 1; $i--) {
	echo "$i ";
}