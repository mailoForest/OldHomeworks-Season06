<?php

$a = 123;

//for ($i = 0; $i < 3; $i++) {
$a % 10;
intval($a / 10);	
	echo $a, ' '; 

