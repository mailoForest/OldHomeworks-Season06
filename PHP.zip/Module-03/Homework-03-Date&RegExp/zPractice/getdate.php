<?php

$ts = mktime(21,46,0,12,13, 1901);

var_dump(getdate()['month']);
var_dump(date("Y.m.d H:i:s", $ts));