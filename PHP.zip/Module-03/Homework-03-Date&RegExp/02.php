<?php
	$year = $_POST['year'];
	$month = $_POST['month'];
	$day = $_POST['day'];
	$hour = $_POST['hour'];
	$min = $_POST['min'];
	$sec = $_POST['sec'];
	
	if (!intval($month)){
		$month = date('n',strtotime($month));
	}
	
	$addYears = $_POST['addYears'];
	$addMonths = $_POST['addMonths'];
	$addDays = $_POST['addDays'];
	$addHours = $_POST['addHours'];
	$addMin = $_POST['addMin'];
	$addSec = $_POST['addSec'];
	
	$ts = mktime( $hour + $addHours, $min + $addMin, $sec + $addSec, $month + $addMonths, $day + $addDays, $year + $addYears);
	
	$format = $_POST['format'];
	$result = date($format, $ts);
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>02</title>
		<style>
		input, output{
			font-size: 1.3em;
		}
		output {
			width: 12em;
			height: 1.4em;	
			border: 1px solid black;
			display: inline-block;
		}
		</style>
	</head>
	<body>
		<form action="" method="post">
		<div>
			<input type="text" placeholder="year" name="year" value=<?= $year + $addYears?> />
			<input type="text" placeholder="month" name="month" value=<?= $month + $addMonths?> />
			<input type="text" placeholder="day" name="day" value=<?= $day + $addDays?> />
			<input type="text" placeholder="hour" name="hour" value=<?= $hour + $addHours?> />
			<input type="text" placeholder="minutes" name="min" value=<?= $min + $addMin?> />
			<input type="text" placeholder="seconds" name="sec" value=<?= $sec + $addSec?> />	
		</div>
		<div>
			<input type="number" placeholder="add years" name="addYears"/>
			<input type="number" placeholder="add months" name="addMonths"/>
			<input type="number" placeholder="add days" name="addDays"/>
			<input type="number" placeholder="add hours" name="addHours"/>
			<input type="number" placeholder="add minutes" name="addMin"/>
			<input type="number" placeholder="add seconds" name="addSec"/>
		</div>
		<div><input type="text" placeholder="format" name="format"/></div>
		<div>
			<output>
				<?php 
					if (empty($result)){
						echo "Don't forget the format!";
					} else {
						echo $result;
					}
				?>
			</output>
		</div>
		<button type="submit">Submit</button>
		</form>
	</body>
</html>