<?php
require_once 'readline.php';

$a = readline('');
$b = readline('');

echo $a + $b, PHP_EOL;
echo $a - $b, PHP_EOL;
echo $a * $b, PHP_EOL;
echo $a / $b, PHP_EOL;
echo $a % $b, PHP_EOL;