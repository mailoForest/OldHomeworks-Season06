<?php

$A = 4;
$B = 2;
echo "A = 4, B = 2", PHP_EOL;
$A = $A>>1;
$B = $B<<1;
echo "A = $A", PHP_EOL;
echo "B = $B", PHP_EOL;