<?php

$a = 5;
$b = 6;
$c = 7;

echo $a + $b + $c;
