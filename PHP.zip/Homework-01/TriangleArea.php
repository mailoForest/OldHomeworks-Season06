<?php

$a=4;
$b=4;
$c=4;

$p=($a+$b+$c)/2;

echo sqrt($p*($p-$a)*($p-$b)*($p-$c));