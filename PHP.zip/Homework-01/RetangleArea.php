<?php

$a = 5;
$b = 7; 

echo $a*$b;