<?php

$radius = 5;

$CircleArea = pi()*$radius**2;

echo $CircleArea;
