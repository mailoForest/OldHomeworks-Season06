<?php

$radius = 5;

$CirclePerimeter = pi()*$radius*2;

echo $CirclePerimeter;
