<?php

$a = 5;
$b = 10;

$perimeter = ($a+$b)*2;

echo $perimeter;